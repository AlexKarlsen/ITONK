﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matcher2
{
    public static class MatcherConnectionFactory
    {
        private static readonly Uri LocationReporterServiceUrl = new Uri("fabric:/TSEIS1/Matcher2");

    }
}
